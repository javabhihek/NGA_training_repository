#include"math.h"
int sum(a,b)
{
    return a+b;
}

int product(a,b)
{
    return a*b;
}