#include<stdio.h>
int main()
{
    int a=2,b=3;
    int sum_r, product_r;

    sum_r=sum(a,b);
    product_r=(a,b);
    printf("Sum=%d\n",sum_r);
    printf("Product=%d",product_r);

    return 0;
}