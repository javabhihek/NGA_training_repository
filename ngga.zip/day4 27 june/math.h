#ifndef MATH_H
#define MATH_H
int a,b;
int sum(a, b);
int product(a,b);
#endif