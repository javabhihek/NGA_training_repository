//Math.h (hadder file)
#ifndef MATH_H
#define MATH_H

int sum(int a,int b);
int product(int a,int b);
#endif