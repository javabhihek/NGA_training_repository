//Math.c function
#include"math.h"
int sum(int a,int b)
{
    return a+b;
}

int product(int a,int b)
{
    return a*b;
}