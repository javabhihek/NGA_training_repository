#include<stdio.h>
int main()
{
    printf("Hello Abhishek!");
    return 0;
}