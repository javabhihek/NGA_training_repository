// #include"mystring.h"
// #include<stdbool.h>

// bool IsPalindrome(const char str[])
// {
//     int left = 0;
//     int right = strlen(str) - 1;

//     while (left < right)
//     {
//         if (str[left] != str[right])
//         {
//             return false;
//         }
//         left++;
//         right--;
//     }
//     return true;
// }

//Above code is mine

//Now the code written by sir which is correct

// mystring.c
// This file will contains function defintion of various useful string related functions
// Author: Himanshu Singh
// Date: 5-Jul-2024
#include <stdbool.h> // To use bool
#include <string.h> // To use strlen()
 
bool IsPalindrome(char str[])
{
    // Declare necessary variables
    int len, repeat;
 
    // Decision variable
    // Assume given string is a Palindrome
    bool flag = true;
 
    // Calculate the length of the string
    len = strlen(str);
 
    // Calculate num of time to check while repeating in the loop
    repeat = len / 2; // Note: it is an integer division, so after division we will get intregal part of the result only
 
    // Palindrome string check approach:
    // Start checking from 1st and last, 
    // then 2nd and second last and repeat this check
    // len / 2 times
 
    for(int i = 0; i < repeat; i++)
    {
        if(str[i] != str[len - i - 1]) // Why str[len - i - 1]? Because len - i I want to start from rear end and -1 more because index starts from 0
        {
            // One first match is found such that corresponding character from left and and right hand when compared are found not eqqual
            // Hence, the given string is not a palindrome, hence set the decision flag = false just don't loop more unncessary and break.
            flag = false;
            break;
        }
    }
    return flag;
}