// #ifndef MYSTRING.H
// #define MYSTRING.H
// #include<stdbool.h>

// bool IsPalindrome(char s[]);
// #endif

//Above code is mine

//Now the code written by sir which is correct

// mystring.h (header file)
// This file will contains function prototypes of various useful string related functions
// Author: Himanshu Singh
// Date: 5-Jul-2024
 
// Include header guards, so that if two or more developers include my header file (mystring.h)
// in thier implementation file (*.c) while using my string function then this file present
// function prototypes are not repeat in the finally combined program during linking phase
#ifndef MYSTRING_H_
#define MYSTRING_H_
 
// Function prototypes
bool IsPalindrome(char str[]);
 
#endif