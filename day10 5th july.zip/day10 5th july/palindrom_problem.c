// main.c (implentation file)
// Problem: C program to check given string is a Palindrome or not.
// This file also contain main() function
// Author: Himanshu Singh
// Date: 5-Jul-2024
// Compile commands using gcc:
// gcc -c -o main.o main.c
// gcc -c -o mystring.o mystring.c
// gcc -o app main.o mystring.o
#include <stdio.h> // To use printf()
#include <stdbool.h> // To use bool
#include "mystring.h" // To use IsPalindrome() function
 
// Driver code or main() function
int main()
{
    // Decision variable
    bool flag;
 
    // Create a string array
    char myStr[100];
 
    // Input the string, we assume here we are taking a string without space
    printf("Enter string:");
    scanf("%s", myStr);
 
    flag = IsPalindrome(myStr);
 
    (flag == true) ? printf("%s is a palindrome.\n", myStr) : printf("%s is not a palindrome.\n", myStr);
 
    return 0;
}